#!/usr/bin/env node
/**
 * Skiing Alps Evaluator JSON Generator
 * 
 * Usage:
 *   node generate-evaluator.js --filename report --ext docx --func compare_docx_files \
 *     --win-cds "scale-cds://..." --ubu-cds "scale-cds://..." --mac-cds "scale-cds://..." \
 *     --options '{"examine_text":true,"ignore_blanks":false}'
 */

const args = process.argv.slice(2);

function getArg(name) {
  const idx = args.indexOf(`--${name}`);
  return idx !== -1 ? args[idx + 1] : null;
}

const filename = getArg('filename') || 'output';
const ext = getArg('ext') || 'docx';
const func = getArg('func') || 'compare_docx_files';
const winCds = getArg('win-cds');
const ubuCds = getArg('ubu-cds');
const macCds = getArg('mac-cds');
const options = JSON.parse(getArg('options') || '{"examine_text":true}');
const taskInit = getArg('task-init') || 'chrome-office';

// App name mapping
const appNames = {
  docx: { ubuntu: 'LibreOffice Writer', windows: 'Word', mac: null },
  pptx: { ubuntu: 'LibreOffice Impress', windows: 'PowerPoint', mac: null },
  xlsx: { ubuntu: 'LibreOffice Calc', windows: 'Excel', mac: null }
};

const app = appNames[ext] || appNames.docx;

// Window name patterns
const windowNames = {
  ubuntu: `${filename}.${ext} - ${app.ubuntu}`,
  windows: `${filename} - ${app.windows}`,  // NO extension on Windows
  mac: `${filename}.${ext}`  // Extension for Office on Mac
};

// Generate evaluator for each OS
function generateEvaluator(os, cdsUrl) {
  if (!cdsUrl) return null;
  
  const evaluator = {
    func: func,
    expected: {
      path: cdsUrl,
      dest: `${filename}_Gold.${ext}`
    },
    result: {
      dest: `${filename}.${ext}`
    },
    options: options,
    postconfig: `activate_window('${windowNames[os]}')`
  };

  return evaluator;
}

// Windows postconfig workaround
function generateWindowsEvaluator(cdsUrl) {
  if (!cdsUrl) return null;

  return {
    func: func,
    expected: {
      path: cdsUrl,
      dest: `${filename}_Gold.${ext}`
    },
    result: {
      dest: `${filename}.${ext}`
    },
    options: options,
    window_name: windowNames.windows,
    postconfig: `import pygetwindow as gw; import pyautogui; import time; win = gw.getWindowsWithTitle('${filename}')[0]; pyautogui.press('alt'); win.restore() if win.isMinimized else None; win.activate(); time.sleep(1); pyautogui.hotkey('ctrl', 's'); time.sleep(2)`
  };
}

// macOS postconfig workaround
function generateMacEvaluator(cdsUrl) {
  if (!cdsUrl) return null;

  const macAppName = {
    docx: 'Microsoft Word',
    pptx: 'Microsoft PowerPoint',
    xlsx: 'Microsoft Excel'
  }[ext] || 'Microsoft Word';

  return {
    func: func,
    expected: {
      path: cdsUrl,
      dest: `${filename}_Gold.${ext}`
    },
    result: {
      dest: `${filename}.${ext}`
    },
    options: options,
    window_name: windowNames.mac,
    postconfig: `import subprocess; import time; subprocess.run(['osascript', '-e', 'tell application "${macAppName}" to activate']); time.sleep(1); import pyautogui; pyautogui.hotkey('command', 's')`
  };
}

console.log('=== WINDOWS EVALUATOR ===');
if (winCds) {
  console.log(JSON.stringify(generateWindowsEvaluator(winCds), null, 2));
} else {
  console.log('(no Windows CDS URL provided)');
}

console.log('\n=== UBUNTU EVALUATOR ===');
if (ubuCds) {
  console.log(JSON.stringify(generateEvaluator('ubuntu', ubuCds), null, 2));
} else {
  console.log('(no Ubuntu CDS URL provided)');
}

console.log('\n=== macOS EVALUATOR ===');
if (macCds) {
  console.log(JSON.stringify(generateMacEvaluator(macCds), null, 2));
} else {
  console.log('(no macOS CDS URL provided)');
}

console.log('\n=== TASK INITIALIZER ===');
console.log(`Task Project Name: ${taskInit}`);

console.log('\n=== CROSS-OS SUMMARY ===');
console.log(`File: ${filename}.${ext}`);
console.log(`Ubuntu path:  /home/user/Desktop/${filename}.${ext}`);
console.log(`Windows path: C:\\Users\\User\\Desktop\\${filename}.${ext}`);
console.log(`macOS path:   /Users/user/Desktop/${filename}.${ext}`);
console.log(`Ubuntu window:  ${windowNames.ubuntu}`);
console.log(`Windows window: ${windowNames.windows}`);
console.log(`macOS window:   ${windowNames.mac}`);
